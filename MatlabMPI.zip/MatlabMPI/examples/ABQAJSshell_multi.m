% ABAQUS 6.6.2 Input File Multi Processor (MPI) Generator for the purposes of analysing cylindrical shells of revolution. 
% Copyright, Adam Jan Sadowski, 2008. 
% Last modified - 16/03/08 - 20.26

% Please run this file from the command line by: eval(MPI_Run('ABQAJSshell_multi',2,{}))
MatMPI_Delete_all, clear all, clc
Heading = ' AJS Master DESIGN SILO LBA k = 0.6 test varying'; % Desired ABAQUS heading
FileName = 'TEST'; %'AJSMaster_GMNIA_ecc_var_S8R5_06_FULL1'; % Don't include the .inp extenesion, it will be appended automatically, also, don't include spaces in the name

% Basic Geometry
Htot = 18000; % Total height of the shell (mm or whatever dimensionless entity) - DO NOT include the hopper or roof height
Ttot = 360; % Total circumferential extent of the shell (degrees)
Rtot = 3000; % Total radial extent of the shell (mm)
write = 1; % Write to file?
draw = 0; labels = 0; % Draw mesh? Label it with node and element numbers? Do NOT choose labels for very fine meshes or Matlab will be busted trying to render it.
drawP = 0; % Draw pressure distributions

% Material Data
MATERIAL = struct('name',[],'Y',[],'v',[],'sy',[],'ep',[]); % Name - Material name; Y - Young's Modulus (MPa); v - Poisson's Ratio; sy - Yield Stress (MPa); ep - Plastic Strain
% NOTE - Leave sy and ep EMPTY for elastic only material, otherwise non-linear material law will be applied
MATERIAL.name = ['Steel']; 
MATERIAL.Y = [2e5]; 
MATERIAL.v = [0.3]; 
MATERIAL.sy = [250 250]; 
MATERIAL.ep = [0 0.2e-3]; 

Rsl = struct('region',[],'h1',[],'h2',[],'Z',[],'t',[],'type',[],'t1',[],'t2',[],'T',[],'Ttot',[]); 
% The 'resolution' node mesh struct 
% Region - numerical ID of the region to be assigned a mesh (>= 1)
% h1, h2, t1 and t2 - the vertical and circumferential extents of this region 
% Z and T - desired number of nodes axially and circumferentially
% t - shell thicknesses per region (mm)

Rsl.region = [1 2]; % Uniform thickness
Rsl.h1 = [0    3000];
Rsl.h2 = [3000 Htot];
Rsl.Z = [16 10];
Rsl.t = [6 6];
Rsl.type = ['a' 'a'];
Rsl.t1 = [0];
Rsl.t2 = [Ttot];
Rsl.T = [10];

%Rsl.region = [1:19]; % Uniform thickness, REFINED for IMPERFECTIONS
%Rsl.h1 = [0    1500 2100 3300 3900 5100 5700 6900 7500 8700 9300  10500 11000 12300 12900 14100 14700 15900 16500];           
%Rsl.h2 = [1500 2100 3300 3900 5100 5700 6900 7500 8700 9300 10500 11000 12300 12900 14100 14700 15900 16500 Htot]; 
%Rsl.Z = [80 30 10 30 10 30 10 30 10 30 10 30 10 30 10 30 10 30 10];
%Rsl.t = 6*ones(1,length(Rsl.region)); 
%Rsl.type = ['h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h'];
%Rsl.t1 = [0];             
%Rsl.t2 = [Ttot];       
%Rsl.T = [100];  % Creates EXACT specified number of 4-node elements, only QUARTER of specified 8-node elements only HALF of 6-node specified elements, and TWICE the number of specified 3-node elements           

%Rsl.region = [1 2 3 4 5 6 7 8 9 10]; % Varying thickness
%Rsl.h1 = [0    3500 3800 4100 6700 7000 7300 9500 9800 13300]; 
%Rsl.h2 = [3500 3800 4100 6700 7000 7300 9500 9800 13300 Htot];
%Rsl.Z = [100 30 30 20 30 30 20 30 100 40];
%Rsl.t = [6 6 5 5 5 4 4 4 3 3];
%Rsl.type = ['h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h'];
%Rsl.t1 = [0];             
%Rsl.t2 = [Ttot];       
%Rsl.T = [100];

%Rsl.region = [1:22]; % Varying thickness, REFINED for IMPERFECTIONS
%Rsl.h1 = [0    1600 2200 3500 3800 4100 5100 5800 6700 7000 7300 8100 8700 9500 9800  10100 11500 12100 13500 14100 15500 16100]; 
%Rsl.h2 = [1600 2200 3500 3800 4100 5100 5800 6700 7000 7300 8100 8700 9500 9800 10100 11500 12100 13500 14100 15500 16100 Htot];
%Rsl.Z = [40 40 50 20 20 20 40 20 20 20 20 40 20 20 40 40 40 40 30 10 30 10];
%Rsl.t = [6 6 6 6 5 5 5 5 5 4 4 4 4 4 3 3 3 3 3 3 3 3];
%Rsl.type = ['h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h'];
%Rsl.t1 = [0];             
%Rsl.t2 = [Ttot];       
%Rsl.T = [100];

%Rsl.region = [1 2   3    4    5    6    7    8    9    10   11   12   13    14    15    16    17    18    19    20    21    22    23]; % Varying thickness, REFINED for IMPERFECTIONS
%Rsl.h1 = [0    1500 2100 3300 3900 5100 5400 5700 6900 7500 8700 9000 9300  10500 11100 12300 12600 12900 14100 14400 14700 15900 16500];
%Rsl.h2 = [1500 2100 3300 3900 5100 5400 5700 6900 7500 8700 9000 9300 10500 11000 12300 12600 12900 14100 14400 14700 15900 16500 Htot];
%Rsl.Z = [80 20 6 20 6 10 10 6 20 6 10 10 6 20 6 10 10 6 10 10 6 20 10];
%Rsl.t = [8 8 8 8 8 8 6 6 6 6 6 5 5 5 5 5 4 4 4 3 3 3 3];
%Rsl.type = ['h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h' 'h'];
%Rsl.t1 = [0];             
%Rsl.t2 = [Ttot];       
%Rsl.T = [100];

% NOTE - Creates EXACT no. of 4-node elements, only QUARTER the no. of 8-node elements, only HALF the no. of 6-node elements, and TWICE the no. of 3-node elements
% NOTE - ABAQUS teaching licenses are limited to 10,000 nodes, ABAQUS student licenses are limited to 1,000 nodes 
% NOTE - Element types; a - S4; b - S4R; c - S4R5; d - S3; e - STRI3; f - STRI65; g - S8R; h - S8R5; j - S9R5
% NOTE - It is not advisable to combine 4-node (including 3-node degenerates) and 8 or 9-node (including 6-node degenerates) elements with each other (though it can be done :) )

% Further structural data
ROOF = struct('angle',[],'h_els',[],'el_type',[],'t',[]); % Specify angle (degrees) to the horizontal of the conical roof, no. of vertical elements and thickness (mm)
ROOF.angle = 15;
ROOF.el_type = 'c'; % Element type, defined as the others
ROOF.h_els = 20; % Set to 0 if you don't want any roof
ROOF.t = 3;

% Weld depression data
WELD = struct('type',[],'Zloc',[],'ampt',[],'pert',[]); % Type (A or B), Zlocation (height coordinate of centre of weld), amplitude (depth) of imperfection in terms of thicknesses, perturbation parameter
WELD.type = ['A' 'A' 'A' 'A' 'A' 'A' 'A' 'A' 'A'];
WELD.Zloc = [1900 3800 5400 7000 8400 9800 11800 13800 15800];%[1800 3600 5400 7200 9000 10800 12600 14400 16200] uniform;
WELD.ampt = [1.397542486 1.530931089 1.530931089 1.711632992 1.711632992 1.976423538 1.976423538 1.976423538 1.976423538];%1.397542486*ones(1,length(WELD.Zloc)); % Depth of welded joint depression imperfection (in units of THICKNESSES of the TOP plate)
WELD.pert = 0.01*ones(1,length(WELD.Zloc)); %Perturbation of each weld into a critical circumferential more (ncr, Eq.8 p. 63 Rotter (Cylindrical shells under axial compression), equation strictly valid for uniform 't' and Type A (t and wo chosen as max)
% From Rotter and Teng 1989, specify whether it is a TYPE A (weld resisting flexural yielding during cooling) or TYPE B (completely resisting flexural yielding during cooling)

% Further imperfection data - choose a vertical region and impose a circumferential mode and magnitude in terms of thicknesses to usher it into earlier buckling
USHER = struct('zmin',[],'zmax',[],'mode',[],'mag',[]);
USHER.zmin = 9800;
USHER.zmax = Htot;
USHER.mode = 22;
USHER.mag = 0;

% Applied load data
LOAD = struct('type',[],'value',[],'step',[]);
LOAD.type = ['d']; 
% a - internal constant pressure only, b - top surface edge load only, c - Janssen static soil pressures (includes frictional traction), d - Janssen eccentric discharge + flow channel pressures
LOAD.value = [3]; % ignored if Janssen pressure desired (options 'c' or 'd')
% give a dimensionless internal pressure of pdim = (p*R)/(sigmacl*t); for pressures (positive radially outwards)
% give a dimensionless line load of Ndim = N/(sigmacl*t) (positive downwards)
LOAD.step = [1]; % The steps, noted in order of creation, in which the load is to be active (loads created in the first step which is to be succeeded by a buckling step
% are kept active but are not proportioned ('dead' loads, in unfortunate ABAQUS terminology)

% IF Janssen pressure is desired (options 'c' or 'd'), include the following solids data:
SOLID = struct('name',[],'weight',[],'K',[],'mewU',[],'mewL',[],'Ch',[],'Cw',[],'frang',[],'flowr',[],'chan',[]);
SOLID.name = 'Wheat'; % name of stored material for information purposes (EN 1991-4:2006 Annex E)
SOLID.weight = 9; % unit weight - kN/m3 (upper characteristic value)
SOLID.K = 0.5994; % lateral pressure ratio - dimensionless (upper characteristic value)
SOLID.mewU = 0.4408; % wall friction coefficient - dimensionless (upper characteristic value)
SOLID.mewL = 0.3276; % wall friction coefficient - dimensionless (lower characteristic value, required for flow channel - EN 1991-4:2006 Section 5.2.4.3.1)
SOLID.Ch = 1.15; % discharge factor for horizontal wall pressures - EN 1991-4
SOLID.Cw = 1.1; % discharge factor for wall frictional tractions  - EN 1991-4
SOLID.frang = 33.6; % internal angle of friction - degrees (upper characteristic value) - IGNORE for 'c'
SOLID.flowr = 0.6*Rtot; % assumed flow channel radius - mm (choose one of rc = kn*r; k1 = 0.25, k2 = 0.4, k3 = 0.6; EN 1991-4:2006 Eqs. 5.52-5.54) - IGNORE for 'c'
SOLID.chan = 0; % relative to Ttot, this is the position of the centre of the flow channel from which +- ThetaC is counted - IGNORE for 'c'

% Created step data
ana = 1601; 
% 10x - static; x - 0 (geom. linear); x - 1 (geom. nonlinear with linear extrapolation); x - 2 (geom. nonlinear with parabolic extrapolation)
% 13x - static, linear perturbation (iterative); x - 0 (geom. linear); x - 1 (geom. nonlinear); DDM requires many tens of thousands of degrees of freedom
% 14x - static, linear perturbation (direct); x - 0 (geom. linear); x - 1 (geom. nonlinear)
% 15xyz - buckling eigenvalue prediction; x - 1 (Lanczos solver for >= 20 eigenvalues); x - 2 (subspace for < 20 eigenvalues); y - 0 (geom. linear); y - 1 (geom. nonlinear); z - 1 (linear); z - 2 (parabolic)
% Note - if buckling eigenvalue is linear, ana reduces to = 15xy
% 16xy - Riks analysis; x - 0 (creates only the Riks step); x - 1 (creates a preceding static preloading step); y - 0 (geom. linear); y - 1 (geom. nonlinear)
stepdata = ([0.5, 1., 1e-05, 0.5]); % Matters only with geometrically nonlinear analyses (default for static linear analysese = [1., 1., 1e-05, 1.] )
% 1 - Initial time increment, 2 - time period of step, 3 - min. time increment allowed, 4 - max. time increment allowed
eigenvalues = ([5,0,99,99,99]); anti = 1; def = 99; inc = 500; % Matters only with buckling eigenvalue analyses, anti - 1 requests antisymmetric buckling modes as well as symmetric ones (for Ttot = 90 degrees only), anti - 2 requests anti only!
% For LANCZOS (* is mandatory, leave equal to whatever 'def' is for default)     For SUBSPACE
% 1* - Number of eigenvalues to be estimated (n)*        "*
% 2  - minimmum (Lanczos)                                maximum (subspace) eigenvalue of interest 
% 3  - maximum (Lanczos) eigenvalue of interest          no. of vectors in iteration (default min(2n,n+8))
% 4  - block size                                        maximum no. of iterations (default 30)
% 5  - maximum no. of Block Lanczos steps
Riks = ([0.01,1,1e-15,0.02,15,-1,3,1e5]); node = 34182; % Matters only with Riks nonlinear analysis (* is mandatory field, leave 0 for default)
% 1  - Initial increment in arc length along static equilibrium path (default is total arc length of step)
% 2  - Total arc length scale factor (default is 1.0)
% 3  - Minimum arc length increment (default is initial arc length or 10e-5 times the total arc length, whichever is smaller)
% 4  - Maximum arc length increment (default is no upper limit)
% 5* - Maximum value of load proportionality factor, used to terminate analysis (leave as zero, will be amended later)*
% 6* - Node number at which finishing displacement value is being monitored (have equal to -1 if you want the top node, -2 if you want to specify it yourself in 'nod', it's YOUR responsibility to check if the node exists!)*
% 7* - Degree of freedom at the node being monitored (1 = x = R, 2 = y = T, 3 = z = Z)*
% 8* - Maximum value of total displacement/rotation at the node & dof, used to terminate analysis*

% Boundary condition data (will be applied in ALL steps)
BC = struct('type',[],'where',[]); % 1 = x = R, 2 = y = T, 3 = z = Z
BC.type  = [22]; 
% 11 - symmetry about line of constant y, YSYMM for U2 = 0
% 12 - symmetry about line of constant x, XSYMM for U1 = 0
% 13 - symmetry about line of constant z, ZSYMM for U3 = 0 
% 3 - the simply supported S3 boundary condition (radially and circumferentially restrained for displacement), U1 = U2 = 0 (will also be U3 = 0 for general static step only)
% 22 - pinned
% 33 - encastr�
% NOTE; for 1/4 of shell use [(left - XSYMM - U1 = 0) 12, (right - YSYMM - U2 = 0) 11)] with Ttot = 90
% NOTE; for 1/2 of shell use [(left - YSYMM - U2 = 0) 11, (right - YSYMM - U2 = 0) 11)] with Ttot = 180
% NOTE; when doing buckling eigenvalue analyses, modelling whole or half of the shell will capture both symmetrical and antisymmetrical modes, whilst the
% quarter shell can naturally only capture symmetrical modes. This has been seen to with the creation of a 2nd buckling step with antisymmetrical
% boundary conditions for Ttot = 90 (XSYMM = XASYMM).
BC.where = [0];
% 11 - left side; 12 - right side; 0 - bottom; 2 - top;

wipe = 0; % clear data from memory at the end?


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hereafter please do not modify the code unless you know exactly what you are doing %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ddd = datestr(now)';
Nodes = struct('index',[],'R',[],'T',[],'Z',[]); % Struct listing node index and radius, theta and z coordinates (cylindrical polar system)
Elements = struct('index',[],'nodes',[],'region',[],'type',[],'t',[],'alt',[]); % Struct listing 4-node or 8-node element indices and node coordinates plus other information
NSet = struct('Bottom',[],'Top',[],'Right',[],'Left',[]);

%if Ttot == 90; BC.type = [12, 11, 33]; BC.where = [11, 12, 0]; elseif Ttot == 180; BC.type = [11, 11, 33]; BC.where = [11, 12, 0]; end

if ROOF.h_els ~= 0; ROOF.angle = pi*ROOF.angle/180; vert = tan(ROOF.angle)*Rtot; % Adding extra region to the mesh
    Rsl.region(length(Rsl.region)+1) = max(Rsl.region)+1; 
    Rsl.h1(length(Rsl.h1)+1) = Htot; Rsl.h2(length(Rsl.h2)+1) = Htot + vert;
    Rsl.Z(length(Rsl.Z)+1) = ROOF.h_els; Rsl.type(length(Rsl.type)+1) = ROOF.el_type; Rsl.t(length(Rsl.t)+1) = ROOF.t; 
    if Ttot == 360; tp = 2; else; tp = 1; end
end

ANA = num2str(ana); t = Rsl.t(1); sigmacl = (MATERIAL.Y*t)/(Rtot*((3*(1-MATERIAL.v*MATERIAL.v))^0.5)); N = sigmacl*t; alt = 2; 
for I = 1:length(LOAD.value); 
    if LOAD.type(I) == 'b'; LOAD.value(I) = sigmacl*t; elseif LOAD.type(I) == 'a'; LOAD.value(I) = LOAD.value(I)*sigmacl*t/Rtot; end;
end
if ANA(2) == '6'; Riks(5) = N; end 
if ANA(2) == '5' & length(LOAD.step) == 1; LOAD.step(1) = 2; end
if isempty(find(LOAD.type == 'c')) == 0 | isempty(find(LOAD.type == 'd')) == 0; % For Janssen static soil pressures (EN 1991-4:2006 Eqs 5.1-5.6)
    SOLID.weight = 1e-6*SOLID.weight; Ar = pi*Rtot*Rtot; U = 2*pi*Rtot; zo = Ar/(SOLID.K*SOLID.mewU*U); pho = SOLID.weight*SOLID.K*zo; end
if isempty(find(LOAD.type == 'd')) == 0; SOLID.frang = SOLID.frang*pi/180; % For flow channel pressure calculation
    eta = SOLID.mewL/tan(SOLID.frang); G = SOLID.flowr/Rtot; ec = Rtot*(eta*(1-G)+(1-eta)*sqrt(1-G)); % ec - flow channel eccentricity (EN 1991-4:2006 Eqs 5.55-5.57)
    cosTHc = (Rtot*Rtot + ec*ec - SOLID.flowr*SOLID.flowr)/(2*Rtot*ec); % angular spread of wall contact with flow channel +- THc (EN 1991-4:2006 Eq. 5.58)
    THc = acos(cosTHc); Psi = asin((Rtot/SOLID.flowr)*sin(THc)); Uwc = 2*THc*Rtot; Usc = 2*SOLID.flowr*(pi - Psi); % arc lengths (EN 1991-4:2006 Eqs 5.59-5.61)
    Ac = (pi - Psi)*SOLID.flowr*SOLID.flowr + THc*Rtot*Rtot - Rtot*SOLID.flowr*sin(Psi - THc); % Cross-sectional area of flow channel (EN 1991-4:2006 Eq. 5.62)
    zoc = (1/SOLID.K)*(Ac/(Uwc*SOLID.mewL + Usc*tan(SOLID.frang))); phco = SOLID.weight*SOLID.K*zoc; % EN 1991-4:2006 Eqs 5.65-5.66
end 

I = 0; J = 0; p1 = pi/180; RemT = []; siz = []; LE = 0; dispbot = 2*length(Rsl.region); tmin = Rsl.t1; tmax = Rsl.t2; Rsl.Ttot = sum(Rsl.T);
MPI_Init; comm = MPI_COMM_WORLD; comm_size = MPI_Comm_size(comm); my_rank = MPI_Comm_rank(comm); % Initialising MPI
for G = 1:length(Rsl.region); % Generating nodes and corresponding elements for every mesh region
    hmax = Rsl.h2(G); hmin = Rsl.h1(G); siz(length(siz)+1) = length(RemT); RemT = [];
    if Rsl.region(G) == Rsl.region(1); hmin = Rsl.h1(G);
    else
        hmin = Rsl.h1(G) + (Rsl.h2(G) - Rsl.h1(G))/Rsl.Z(G);
    end
    Rno = abs(hmax - Rsl.h1(G))/Rsl.Z(G);
    for Z = hmin:Rno:hmax; 
        if G == length(Rsl.region) & ROOF.h_els ~= 0; dtxt = ' (roof)'; else; dtxt = ''; end
        clc; disp(['      Generating nodes. Z Region ',num2str(G),dtxt,' - ',num2str(LE+(Z/hmax)*(1/dispbot)*100),' %']); if Z == hmax; LZ = LE+(Z/hmax)*(1/dispbot)*100; end
        for A = 1:length(Rsl.t1); 
            tmax = Rsl.t2(A); tmin = Rsl.t1(A); Tno = abs(tmax - tmin)/Rsl.T(A);
            if A == 1; tmin = tmin; else; tmin = tmin + Tno; end                
            for T = tmin:Tno:tmax; I = I + 1; 
                if (Ttot == 360 & T == 360); RemT(length(RemT)+1) = I; continue; end
                Nodes.index(length(Nodes.index)+1) = I;
                if ROOF.h_els ~= 0 & G == length(Rsl.region); NR = Rtot - (Z-Htot)/tan(ROOF.angle); else; NR = Rtot; end
                if isempty(WELD.ampt) == 0 & G ~= length(Rsl.region); do = 1; clear('ncr');
                    ncr = (0.822 - 0.25*max(WELD.ampt)/max(Rsl.t))*sqrt(Rtot/max(Rsl.t)); 
                    delta = pi*sqrt(Rtot*Rsl.t(G))/(3*(1-MATERIAL.v*MATERIAL.v))^0.25;               
                    for W = 1:length(WELD.Zloc); ZR = abs(WELD.Zloc(W) - Z);
                        if WELD.type == 'A'; s = 1; elseif WELD.type == 'B'; s = 0; end
                        ampt = WELD.ampt(W)*Rsl.t(G+1); 
                        NR = NR - ampt*exp(-ZR*pi/delta)*(cos(pi*ZR/delta)+s*sin(pi*ZR/delta))*(1+WELD.pert(W)*cos(ncr*pi*T/180));
                    end
                else do = 0;
                end
                if isempty(USHER.mode) == 0;
                    if hmin >= USHER.zmin & hmax <= USHER.zmax; NR = NR - USHER.mag*Rsl.t(G)*cos(USHER.mode*pi*T/180); end
                end
                Nodes.R(length(Nodes.R)+1) = NR; Nodes.T(length(Nodes.T)+1) = T; Nodes.Z(length(Nodes.Z)+1) = Z;
                if Nodes.Z == 0; NSet.Bottom(length(NSet.Bottom)+1) = I; end
                if Nodes.Z == Htot; NSet.Top(length(NSet.Top)+1) = I; end
                if Ttot ~= 360; 
                    if T == min(Rsl.t1); NSet.Right(length(NSet.Right)+1) = I; end
                    if T == max(Rsl.t2); NSet.Left(length(NSet.Left)+1) = I; end
                end
            end
        end
    end
    if Ttot == 360; 
        correction = RemT - Rsl.Ttot; 
        if G > 1; RemT(length(RemT) + 1) = RL; correction(length(correction) + 1) = RL - Rsl.Ttot; end
    end
    if ROOF.h_els ~= 0 & G == length(Rsl.region); 
        RemR = Nodes.index((length(Nodes.index)-Rsl.Ttot+tp):length(Nodes.index));
        Nodes.index((length(Nodes.index)-Rsl.Ttot+tp):length(Nodes.index)) = []; Nodes.R((length(Nodes.R)-Rsl.Ttot+tp):length(Nodes.R))= [];
        Nodes.T((length(Nodes.T)-Rsl.Ttot+tp):length(Nodes.T)) = []; Nodes.Z((length(Nodes.Z)-Rsl.Ttot+tp):length(Nodes.Z)) = [];
        if Ttot == 360; RemT(length(RemT)+1:length(RemT)+length(RemR)) = RemR; correction(length(correction)+1:length(correction)+length(RemR)) = max(Nodes.index)*ones(1,length(RemR)); 
        else RemT = RemR; correction = max(Nodes.index)*ones(1,length(RemR)); 
        end
    end
    for E = 1:length(Rsl.region); % The generation of elements has element normals going out of the shell, thus the SNEG face is on the inside, and the SPOS on the outside.
            RTcurrent = Rsl.Ttot+1; 
            if Rsl.region(G) == Rsl.region(1); BaseZ = 1; else; BaseZ = sum(Rsl.Z(1:G-1))+1; end
            if Rsl.type(E) == 'a' | Rsl.type(E) == 'b' | Rsl.type(E) == 'c'; % If it is a 4-node element
                for Zn = BaseZ:(BaseZ + Rsl.Z(G) - 1); % For every row but one of vertical nodes        
                    clc; disp(['      Generating 4-node elements. E Region ',num2str(G),' - ',num2str(LZ+(Zn/(BaseZ + Rsl.Z(G) - 1))*(1/dispbot)*100),' %']); 
                    if Zn == (BaseZ + Rsl.Z(G) - 1); LE = LZ+(Zn/(BaseZ + Rsl.Z(G) - 1))*(1/dispbot)*100; end
                    for Tn = 1:Rsl.Ttot; J = J + 1; % For every column but one of circumferential nodes
                        Elements.region(length(Elements.region)+1) = Rsl.region(E); Elements.type(length(Elements.type)+1) = Rsl.type(E); Elements.index(length(Elements.index)+1) = J;
                        Elements.nodes(J,1) = Tn + (Zn-1)*RTcurrent; Elements.nodes(J,2) = Tn + 1 + (Zn-1)*RTcurrent;
                        Elements.nodes(J,3) = Tn + 1 + Zn*RTcurrent; Elements.nodes(J,4) = Tn + Zn*RTcurrent; 
                        Elements.t(length(Elements.t)+1) = Rsl.t(E);
                        if (Ttot == 360 | (ROOF.h_els ~= 0 & G == length(Rsl.region)));
                            for K = 1:length(RemT);
                                clear('A'); A = find(Elements.nodes(J,:) == RemT(K)); if isempty(A) ~= 1; Elements.nodes(J,A) = correction(K); end
                            end  
                        end
                    end 
                end
            elseif Rsl.type(E) == 'd' | Rsl.type(E) == 'e'; % If it is a 3-node element
                for Zn = BaseZ:(BaseZ + Rsl.Z(G) - 1); % For every row but one of vertical nodes
                    clc; disp(['      Generating 3-node elements. E Region ',num2str(G),' - ',num2str(LZ+(Zn/(BaseZ + Rsl.Z(G) - 1))*(1/dispbot)*100),' %']); 
                    if Zn == (BaseZ + Rsl.Z(G) - 1); LE = LZ+(Zn/(BaseZ + Rsl.Z(G) - 1))*(1/dispbot)*100; end
                    for Tn = 1:Rsl.Ttot; J = J + 1; % For every column but one of circumferential nodes
                        % Is it the triangular element with 2 nodes at bottom (alt = 1) or 2 nodes at top (alt = 2)
                        Elements.region(J) = Rsl.region(E); Elements.type(J) = Rsl.type(E); Elements.index(J) = J; 
                        Elements.nodes(J,1) = Tn + (Zn-1)*RTcurrent; Elements.nodes(J,2) = Tn + 1 + (Zn-1)*RTcurrent; Elements.nodes(J,3) = Tn + 1 + Zn*RTcurrent; Elements.alt(J) = 1; 
                        if Ttot == 360;
                            for K = 1:length(RemT);
                                clear('A'); A = find(Elements.nodes(J,:) == RemT(K)); if isempty(A) ~= 1; Elements.nodes(J,A) = correction(K); end
                            end  
                        end                          
                        J = J + 1; Elements.region(J) = Rsl.region(E); Elements.type(J) = Rsl.type(E); Elements.index(J) = J;
                        Elements.nodes(J,1) = Tn + 1 + Zn*RTcurrent; Elements.nodes(J,2) = Tn + Zn*RTcurrent; Elements.nodes(J,3) = Tn + (Zn-1)*RTcurrent; Elements.alt(J) = 2;
                        Elements.t(length(Elements.t)+1) = Rsl.t(E);
                        if (Ttot == 360 | (ROOF.h_els ~= 0 & G == length(Rsl.region)));
                            for K = 1:length(RemT);
                                clear('A'); A = find(Elements.nodes(J,:) == RemT(K)); if isempty(A) ~= 1; Elements.nodes(J,A) = correction(K); end
                            end  
                        end                  
                    end
                end
            elseif Rsl.type(E) == 'f'; % If it is a 6-node element
                for Zn = BaseZ:2:(BaseZ + Rsl.Z(G)-2);
                    clc; disp(['      Generating 6-node elements. E Region ',num2str(G),' - ',num2str(LZ+(Zn/(BaseZ + Rsl.Z(G)-2))*(1/dispbot)*100),' %']); 
                    if Zn == (BaseZ + Rsl.Z(G)-2); LE = LZ+(Zn/(BaseZ + Rsl.Z(G)-2))*(1/dispbot)*100; end
                    for Tn = 1:2:Rsl.Ttot; J = J + 1;
                        Elements.region(J) = Rsl.region(E); Elements.type(J) = Rsl.type(E); Elements.index(J) = J; Elements.alt(J) = 1;
                        Elements.nodes(J,1) = Tn + (Zn-1)*RTcurrent; Elements.nodes(J,2) = Tn + 2 + (Zn-1)*RTcurrent;
                        Elements.nodes(J,3) = Tn + 2 + (Zn+1)*RTcurrent; Elements.nodes(J,4) = Tn + 1 + (Zn-1)*RTcurrent;
                        Elements.nodes(J,5) = Tn + 2 + Zn*RTcurrent; Elements.nodes(J,6) = Tn + 1 + Zn*RTcurrent; 
                        if Ttot == 360;
                            for K = 1:length(RemT);
                                clear('A'); A = find(Elements.nodes(J,:) == RemT(K)); if isempty(A) ~= 1; Elements.nodes(J,A) = correction(K); end
                            end  
                        end
                        J = J + 1; Elements.region(J) = Rsl.region(E); Elements.type(J) = Rsl.type(E); Elements.index(J) = J; Elements.alt(J) = 2;
                        Elements.nodes(J,1) = Tn + 2 + (Zn+1)*RTcurrent; Elements.nodes(J,2) = Tn + (Zn+1)*RTcurrent;
                        Elements.nodes(J,3) = Tn + (Zn-1)*RTcurrent; Elements.nodes(J,4) = Tn + 1 + (Zn+1)*RTcurrent;
                        Elements.nodes(J,5) = Tn + Zn*RTcurrent; Elements.nodes(J,6) = Tn + 1 + Zn*RTcurrent;
                        Elements.t(length(Elements.t)+1) = Rsl.t(E);
                        if (Ttot == 360 | (ROOF.h_els ~= 0 & G == length(Rsl.region)));
                            for K = 1:length(RemT);
                                clear('A'); A = find(Elements.nodes(J,:) == RemT(K)); if isempty(A) ~= 1; Elements.nodes(J,A) = correction(K); end
                            end  
                        end                       
                    end
                end                        
            elseif Rsl.type(E) == 'f' | Rsl.type(E) == 'g' | Rsl.type(E) == 'h' | Rsl.type(E) == 'j'; % If it is an 8-node or 9-node element
                for Zn = BaseZ:2:(BaseZ + Rsl.Z(G)-2); % For every row but one of vertical nodes 
                    clc; disp(['      Generating 8/9-node elements. E Region ',num2str(G),' - ',num2str(LZ+(Zn/(BaseZ + Rsl.Z(G)-2))*(1/dispbot)*100),' %']); 
                    if Zn == (BaseZ + Rsl.Z(G)-2); LE = LZ+(Zn/(BaseZ + Rsl.Z(G)-2))*(1/dispbot)*100; end
                    for Tn = 1:2:Rsl.Ttot; J = J + 1; % For every column but one of circumferential nodes
                        Elements.region(length(Elements.region)+1) = Rsl.region(E); Elements.type(length(Elements.type)+1) = Rsl.type(E); Elements.index(length(Elements.index)+1) = J; 
                        Elements.nodes(J,1) = Tn + (Zn-1)*RTcurrent; Elements.nodes(J,2) = Tn + 2 + (Zn-1)*RTcurrent;
                        Elements.nodes(J,3) = Tn + 2 + (Zn+1)*RTcurrent; Elements.nodes(J,4) = Tn + (Zn+1)*RTcurrent;
                        Elements.nodes(J,5) = Tn + 1 + (Zn-1)*RTcurrent; Elements.nodes(J,6) = Tn + 2 + Zn*RTcurrent;
                        Elements.nodes(J,7) = Tn + 1 + (Zn+1)*RTcurrent; Elements.nodes(J,8) = Tn + Zn*RTcurrent;
                        if Rsl.type(E) == 'j'; Elements.nodes(J,9) = Tn + 1 + Zn*RTcurrent; end
                        Elements.t(length(Elements.t)+1) = Rsl.t(E);
                        if (Ttot == 360 | (ROOF.h_els ~= 0 & G == length(Rsl.region)));
                            for K = 1:length(RemT);
                                clear('A'); A = find(Elements.nodes(J,:) == RemT(K)); if isempty(A) ~= 1; Elements.nodes(J,A) = correction(K); end
                            end  
                        end
                    end
                end
            end
    end
    if Ttot == 360;
        if G > 1; RemT(length(RemT)) = []; correction(length(correction)) = []; end; RL = RemT(length(RemT)); 
    end
end

if write == 1; % Writing the ABAQUS input file
    clc; disp('      Writing ABAQUS input file'); disp(' ');
    format4 = ['%1.f, %1.6f, %1.6f, %1.6f\n']; formate4 = ['%1.f, %1.f, %1.f, %1.f\n'];
    format5 = ['%1.f, %1.f, %1.f, %1.f, %1.f\n']; format7 = ['%1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f\n'];
    format9 = ['%1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f\n']; 
    format10 = ['%1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f, %1.f\n']; 
    ext = '.inp'; for I = 1:length(ext); FileName(length(FileName)+1) = ext(I); end
    fid = fopen(FileName,'w'); 
    
    %---% Writing Heading
    fprintf(fid,'%s\n','*HEADING'); fprintf(fid,'%s\n',[Heading,' CREATED ON ',datestr(now)]); 
    fprintf(fid,'%s\n',['** This ABAQUS v6.6.2 input file generates ',num2str(length(Nodes.index)),' nodes']);
    for E = 1:length(Rsl.type);
        if Rsl.type(E) == 'a'; tip(E,:) = 'S4    '; els(E) = Rsl.Z(E)*Rsl.Ttot;
        elseif Rsl.type(E) == 'b'; tip(E,:) = 'S4R   '; els(E) = Rsl.Z(E)*Rsl.Ttot;
        elseif Rsl.type(E) == 'c'; tip(E,:) = 'S4R5  '; els(E) = Rsl.Z(E)*Rsl.Ttot; 
        elseif Rsl.type(E) == 'd'; tip(E,:) = 'S3    '; els(E) = Rsl.Z(E)*Rsl.Ttot*2; 
        elseif Rsl.type(E) == 'e'; tip(E,:) = 'STRI3 '; els(E) = Rsl.Z(E)*Rsl.Ttot*2; 
        elseif Rsl.type(E) == 'f'; tip(E,:) = 'STRI65'; els(E) = Rsl.Z(E)*Rsl.Ttot/2;  
        elseif Rsl.type(E) == 'g'; tip(E,:) = 'S8R   '; els(E) = Rsl.Z(E)*Rsl.Ttot/4; 
        elseif Rsl.type(E) == 'h'; tip(E,:) = 'S8R5  '; els(E) = Rsl.Z(E)*Rsl.Ttot/4; 
        elseif Rsl.type(E) == 'j'; tip(E,:) = 'S9R5  '; els(E) = Rsl.Z(E)*Rsl.Ttot/4; 
        end
        if length(Rsl.t) > 1; ex = [' with thickness t = ',num2str(Rsl.t(E)),' mm.']; else; ex = '.'; end
        fprintf(fid,'%s\n',['** This input file generates ',num2str(els(E)),' elements of type ',tip(E,:),'between z = ',num2str(Rsl.h1(E)),' and ',num2str(Rsl.h2(E)),' mm',ex]);
    end
    fprintf(fid,'%s\n',['** Element total is ',num2str(sum(els))]); if length(Rsl.t) == 1; fprintf(fid,'%s\n',['** Uniform shell thickness of ',num2str(t),' mm']); end
    for W = 1:length(WELD.type);
        fprintf(fid,'%s\n',['** The coordinates enjoy a weld imperfection of type ',WELD.type(W),' at a height of ',num2str(WELD.Zloc(W)),' mm with an amplitude of ',num2str(WELD.ampt(W)),' thicknesses']); 
    end
    fprintf(fid,'%s\n','**');
    
    %---% Writing Part
    txt = (['*PART, NAME=SHELL_PART']); fprintf(fid,'%s\n',txt); 
    
    %---% Writing Nodes
    txt = (['*NODE, SYSTEM=C']); fprintf(fid,'%s\n',txt);
    for L = 1:length(Nodes.index); line = [Nodes.index(L),Nodes.R(L),Nodes.T(L),Nodes.Z(L)];
        fprintf(fid,format4,line);
    end
    
    %---% Writing Elements
    for E = 1:length(Rsl.region);
        if char(Rsl.type(E)) == 'a'; tip = 'S4'; frmt = format5; N = 4; end % 4-node general purpose, double curved, finite membrane strains (suitable for large-strain analysis), thick and thin shells
        if char(Rsl.type(E)) == 'b'; tip = 'S4R'; frmt = format5; N = 4; end % Reduced Integration, hourglass control, finite membrane strains
        if char(Rsl.type(E)) == 'c'; tip = 'S4R5'; frmt = format5; N = 4; end % S4R with small membrane strains (5 degrees of freedom per node), thin shells only
        if char(Rsl.type(E)) == 'd'; tip = 'S3'; frmt = formate4; N = 3; end % 3-node triangular general purpose, double curved, finite membrane strains, thick and thin shells
        if char(Rsl.type(E)) == 'e'; tip = 'STRI3'; frmt = formate4; N = 3; end % 3-node triangular facet thin shell element
        if char(Rsl.type(E)) == 'f'; tip = 'STRI65'; frmt = format7; N = 6; end % 6-node triangular (5 degrees of freedom per node), thin shells only
        if char(Rsl.type(E)) == 'g'; tip = 'S8R'; frmt = format9; N = 8; end % 8-node general purpose, double curved, thick shell, small membrane strains, reduced integration
        if char(Rsl.type(E)) == 'h'; tip = 'S8R5'; frmt = format9; N = 8; end % S8R with 5 degrees of freedom per node, thin shells only
        if char(Rsl.type(E)) == 'j'; tip = 'S9R5'; frmt = format10; N = 9; end % 9-node with 5 degrees of freedom per node, thin shells only
        txt = (['*ELEMENT, TYPE=',tip]); fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n',txt);
        for L = 1:length(Elements.region);
            if Elements.region(L) == Rsl.region(E);
                line = [Elements.index(L),Elements.nodes(L,(1:N))];
                fprintf(fid,frmt,line);
            end
        end
    end
    fprintf(fid,'%s\n','**');
    
    %---% Writing Section Assignment
    fprintf(fid,'%s\n','*NSET, NSET=NTOTAL, INTERNAL, GENERATE');
    fprintf(fid,'%1.f, %1.f, %1.f\n',[min(Nodes.index),max(Nodes.index),1]);
    fprintf(fid,'%s\n','*ELSET, ELSET=ETOTAL, INTERNAL, GENERATE');
    fprintf(fid,'%1.f, %1.f, %1.f\n',[min(Elements.index),max(Elements.index),1]);
    if isempty(MATERIAL.sy) == 0 | isempty(MATERIAL.ep) == 0 | length(MATERIAL.sy) ~= length(MATERIAL.ep); sect = ''; integ = ', SECTION INTEGRATION=SIMPSON'; else; sect = ' GENERAL'; integ = ''; end
    if length(Rsl.t) == 1; fprintf(fid,'%s\n',['*SHELL',sect,' SECTION, ELSET=ETOTAL, MATERIAL=STEEL',integ]); fprintf(fid,'%1.3f\n',t); 
    else; tsofar = [];
        for T = 1:length(Rsl.t); tsofar(length(tsofar)+1) = Rsl.t(T); clear('ex');
            if isempty(find(tsofar==Rsl.t(T))) == 0; ex = ['_',num2str(length(find(tsofar==Rsl.t(T))))]; else; ex = (''); end
            if T == 1; ebot = 1; etop = length(find(Elements.region==T)); 
            else; ebot = 1 + max(find(Elements.region==(T-1))); etop = max(find(Elements.region==(T-1))) + length(find(Elements.region==T)); end            
            fprintf(fid,'%s\n',['*ELSET, ELSET=EL_',num2str(Rsl.t(T)),ex,', INTERNAL, GENERATE']); fprintf(fid,'%1.f, %1.f, %1.f\n',[ebot,etop,1]);
            fprintf(fid,'%s\n',['*SHELL',sect,' SECTION, ELSET=EL_',num2str(Rsl.t(T)),ex,', MATERIAL=STEEL',integ]); fprintf(fid,'%1.3f\n',Rsl.t(T)); 
        end
    end            
    fprintf(fid,'%s\n','*END PART'); fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n','**');
    
    %---% Writing Assembly
    fprintf(fid,'%s\n','*ASSEMBLY, NAME=SHELL_ASSEMBLY'); 
    fprintf(fid,'%s\n','*INSTANCE, NAME=SHELL_INSTANCE, PART=SHELL_PART');
    fprintf(fid,'%s\n','*END INSTANCE'); 
    for L = 1:length(LOAD.value);
        if LOAD.type(L) == 'a'; % internal pressure, defining internal surface
            fprintf(fid,'%s\n','*ELSET, ELSET=ETOTAL, INTERNAL, INSTANCE=SHELL_INSTANCE, GENERATE');
            fprintf(fid,'%1.f, %1.f, %1.f\n',[min(Elements.index),max(Elements.index),1]);
            fprintf(fid,'%s\n','*SURFACE, TYPE=ELEMENT, NAME=INNER_SURFACE, INTERNAL');
            fprintf(fid,'%s\n','ETOTAL, SNEG');
        end% NOTE - Element types; a - S4; b - S4R; c - S4R5; d - S3; e - STRI65; g - S8R; h - S8R5; j - S9R5
        if LOAD.type(L) == 'b'; % shell edge load, defining top shell edge
            fprintf(fid,'%s\n','*ELSET, ELSET=ETOP, INTERNAL, INSTANCE=SHELL_INSTANCE, GENERATE');
            Eltop = char(Elements.type(length(Elements.type)));
            if Eltop == 'a' | Eltop == 'b' | Eltop == 'c'; Rsltop = Rsl.Ttot; step = 1; adj = 1; txt = 'ETOP, E3'; end
            if Eltop == 'd' | Eltop == 'e'; Rsltop = Rsl.Ttot*2; step = 2; adj = 2; txt = 'ETOP, E1'; end
            if Eltop == 'f'; Rsltop = Rsl.Ttot; step = 2; adj = 2; txt = 'ETOP, E1'; end
            if Eltop == 'g' | Eltop == 'h' | Eltop == 'j'; Rsltop = Rsl.Ttot/2; step = 1; adj = 1; txt = 'ETOP, E3'; end
            fprintf(fid,'%1.f, %1.f, %1.f\n',[Elements.index(length(Elements.index))-Rsltop+adj,max(Elements.index),step]);
            fprintf(fid,'%s\n','*SURFACE, TYPE=ELEMENT, NAME=TOP_EDGE, INTERNAL');
            fprintf(fid,'%s\n',txt); % For 4 and 8-node elements, E3 is the element surface corresponding to the top edge, for 3 and 6-node elements, it is E1.
        end
    end
    for B = 1:length(BC.type); no = 0;
        if BC.where(B) == 0; ndsn = 'BOTTOM'; nds = NSet.Bottom; end % bottom set of nodes
        if BC.where(B) == 11; if Ttot ~= 360; ndsn = 'LEFT'; nds = NSet.Left; else; no = 1; end; end % left side set of nodes
        if BC.where(B) == 12; if Ttot ~= 360; ndsn = 'RIGHT'; nds = NSet.Right; else; no = 1; end; end % right side set of nodes
        if BC.where(B) == 2; ndsn = 'TOP'; nds = NSet.Top; end % top set of nodes  
        if no ~= 1;
            txt = (['*NSET, NSET=',ndsn,', INTERNAL, INSTANCE=SHELL_INSTANCE']);
            fprintf(fid,'%s\n',txt); C = 0; A = []; frmt = '';
            for I = 1:length(nds); 
                C = C + 1;
                if C < 16 & I < length(nds); A(length(A)+1) = nds(I); 
                elseif C == 16 | I == length(nds);  A(length(A)+1) = nds(I); 
                    for a = 1:length(A);
                        frmt(length(frmt)+1) = '%'; frmt(length(frmt)+1) = num2str(1); frmt(length(frmt)+1) = '.'; frmt(length(frmt)+1) = 'f';
                        if a < length(A); frmt(length(frmt)+1) = ','; frmt(length(frmt)+1) = ' ';
                        else; frmt(length(frmt)+1) = '\'; frmt(length(frmt)+1) = 'n'; end
                    end        
                    if BC.where(B) == 2 & I <= 16 & Ttot ~= 360; A(1) = []; frmt(1:6) = []; end
                    if BC.where(B) == 2 & I == length(nds) & Ttot ~= 360; A(length(A)) = []; frmt(1:6) = []; end
                    fprintf(fid,frmt,A); 
                    C = 0; A = []; frmt = '';
                end   
            end
        end
    end   
    if ANA(2) == '6'; fprintf(fid,'%s\n','*NSET, NSET=RIKS, INSTANCE=SHELL_INSTANCE'); 
        if Riks(6) == -1; fprintf(fid,'%1.f\n',find(Nodes.Z==Htot & Nodes.T==0)); end
        if Riks(6) == -2; fprintf(fid,'%s\n',num2str(node)); end
    end
    if isempty(find(BC.where == 0)) == 0; fprintf(fid,'%s\n','*TRANSFORM, NSET=BOTTOM, TYPE=C'); fprintf(fid,'%1.f, %1.f, %1.f, %1.f, %1.f, %1.f\n',([0,0,0,0,0,1])); end
    if isempty(find(BC.where == 2)) == 0; fprintf(fid,'%s\n','*TRANSFORM, NSET=TOP, TYPE=C'); fprintf(fid,'%1.f, %1.f, %1.f, %1.f, %1.f, %1.f\n',([0,0,0,0,0,1])); end
    fprintf(fid,'%s\n','*END ASSEMBLY'); fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n','**');
    
    %---% Writing Materials
    fprintf(fid,'%s\n',['*MATERIAL, NAME=',MATERIAL.name]); 
    fprintf(fid,'%s\n','*ELASTIC'); fprintf(fid,'%1.f, %2.1f\n',[MATERIAL.Y;MATERIAL.v]); % Elastic material definition
    if isempty(MATERIAL.sy) == 0 | isempty(MATERIAL.ep) == 0; 
        fprintf(fid,'%s\n','*PLASTIC, HARDENING=ISOTROPIC'); fprintf(fid,'%1.f, %2.e\n',[MATERIAL.sy;MATERIAL.ep]); % Plastic material definition
    end    
    fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n','**');   
    
    %---% Writing First Created Static Load Step
    if ana == 1600 | ana == 1601 | ANA(2) == '5'; no = 0; else; no = 1; end
    if no == 1; % Static step not made for nonlinear Riks or Eigenvalue Buckling
        if (ANA(2) == '0' & ANA(3) == '0') | (ANA(2) == '5' & ANA(4) == '0'); % General linear static step
            fprintf(fid,'%s\n',['*STEP, NAME=',LD]); fprintf(fid,'%s\n',LD); end;
        if (ANA(2) == '6' & ANA(3) == '1'); fprintf(fid,'%s\n',['*STEP, NAME=',LD,', NLGEOM=YES']); end
        if (ANA(2) == '0' & ANA(3) == '1') | (ANA(2) == '0' & ANA(3) == '2') | (ANA(2) == '5' & ANA(4) == '1') | (ANA(2) == '5' & ANA(4) == '2'); % Nonlinear static step
            if ANA(3) == '1' | ANA(4) == '1'; extr = 'LINEAR'; elseif ANA(3) == '2' | ANA(4) == '2'; extr = 'PARABOLIC'; end
            fprintf(fid,'%s\n',['*STEP, NAME=',LD,', NLGEOM=YES, EXTRAPOLATION=',extr]); end
        if ANA(2) == '3'; % Linear perturbation static step, linear or nonlinear 
            if ANA(3) == '0'; solv = ', SOLVER=DDM'; end % Domain Decomposition Iterative linear equation solver (requires many thousands of degrees of freedom)
            if ANA(3) == '1'; solv = ''; end % Direct Sparse Solver (default)
            if ANA(4) == '0'; nlgeom = ''; stepdata = []; end % Linear geometry
            if ANA(4) == '1'; nlgeom = ', NLGEOM=YES'; end % Nonlinear geometry
            fprintf(fid,'%s\n',['*STEP, NAME=',LD,', PERTURBATION',solv,nlgeom]); end
        fprintf(fid,'%s\n','*STATIC'); fprintf(fid,'%1.5f, %1.5f, %1.e, %1.5f\n',stepdata); % Creating static step						
        fprintf(fid,'%s\n','**');
        
        %---% Writing Boundary Conditions for Static Load Step
        for B = 1:length(BC.type); no = 0;
            if BC.type(B) == 11; if Ttot ~= 360; BCs = 'YSYMM'; else; no = 1; end; end % symmetry about line of constant y, YSYMM for U2 = 0 (i.e. left)
            if BC.type(B) == 12; if Ttot ~= 360; BCs = 'XSYMM'; else; no = 1; end; end % symmetry about line of constant x, XSYMM for U1 = 0 (i.e. right)
            if BC.type(B) == 13; BCs = 'ZSYMM'; end % symmetry about line of constant z, ZSYMM for U3 = 0 
            if BC.type(B) == 22; BCs = 'PINNED'; end % pinned
            if BC.type(B) == 33; BCs = 'ENCASTRE'; end % encastr�  
            if BC.where(B) == 0; ndsn = 'Bottom'; nds = NSet.Bottom; end % bottom set of nodes
            if BC.where(B) == 11; if Ttot ~= 360; ndsn = 'Left'; nds = NSet.Left; else; no = 1; end; end % left side set of nodes
            if BC.where(B) == 12; if Ttot ~= 360; ndsn = 'Right'; nds = NSet.Right; else; no = 1; end; end % right side set of nodes
            if BC.where(B) == 2; ndsn = 'Top'; nds = NSet.Top; end % top set of nodes  
            if BC.type(B) ~= 3 & no ~= 1; fprintf(fid,'%s\n','*BOUNDARY'); fprintf(fid,'%s\n',([ndsn,', ',BCs])); end        
            if BC.type(B) == 3; % 3 - the simply supported S3 boundary condition (radially and circumferentially restrained for displacement), U1 = U2 = 0
                fprintf(fid,'%s\n','*BOUNDARY'); if BC.where(B) == 0; BCs = [1 2 3]; else; BCs = [1 2]; end; % In the static step, there must be an axial restraint, hence U3 = 0 also
                for I = 1:length(BCs); fprintf(fid,'%s\n',([ndsn,', ',num2str(BCs(I))])); end; end 
        end
        fprintf(fid,'%s\n','**');
        
        %---% Writing Applied Loads for First Load Step
        for L = 1:length(LOAD.value);
            if LOAD.type(L) == 'a' & LOAD.step(L) == 1; % internal pressure defined in first analysis step
                fprintf(fid,'%s\n','*DSLOAD');
                txt = (['INNER_SURFACE, P, ',num2str(LOAD.value(L))]);
                fprintf(fid,'%s\n',txt);           
            end
            if LOAD.type(L) == 'b' & LOAD.step(L) == 1; % shell edge load along the top edge defined in first analysis step
                fprintf(fid,'%s\n','*DSLOAD');
                txt = (['TOP_EDGE, EDNOR, ',num2str(LOAD.value(L))]);
                fprintf(fid,'%s\n',txt);
            end
            if (LOAD.type(L) == 'c' | LOAD.type(L) == 'd') & LOAD.step(L) == 2; clear('txt'); % Janssen pressure generates both normal pressure and friction surface traction
                if LOAD.type(L) == 'd'; tx = ' with eccentric discharge flow channel'; THc = THc*180/pi; 
                    POS_2min = SOLID.chan - 2*THc; if POS_2min < 0; POS_2min = 360 + POS_2min; out = 1; end
                    POS_min = SOLID.chan - THc; if POS_min < 0; POS_min = 360 + POS_min; out = 1; end
                    POS_max = SOLID.chan + THc; if POS_max > 360; POS_max = POS_max - 360; out = 1; end
                    POS_2max = SOLID.chan + 2*THc; if POS_2max > 360; POS_2max = POS_2max - 360; out = 1; end                         
                else tx = ''; 
                end
                fprintf(fid,'%s\n',['** Definition of Janssen internal pressures and frictional tractions',tx]); 
                fprintf(fid,'%s\n','*DLOAD'); txt = 'SHELL_INSTANCE.'; txtP = ', P, '; txtF1 = ', TRSHR, '; txtF2 = ', 0., 0., -1.'; out = 0;
                for E = 1:length(Elements.index);
                    if Elements.region(E) == max(Rsl.region) & ROOF.h_els ~= 0; continue; end
                    txt1 = txt; txt2 = txt; ee = num2str(E);
                    e1 = Elements.nodes(E,1); f1 = find(Nodes.index == e1); e2 = Elements.nodes(E,2); f2 = find(Nodes.index == e2); e3 = Elements.nodes(E,3); f3 = find(Nodes.index == e3);
                    Z1 = Nodes.Z(f1); Z2 = Nodes.Z(f2); Z3 = Nodes.Z(f3); T1 = Nodes.T(f1); T2 = Nodes.T(f2); T3 = Nodes.T(f3);
                    zmid = Htot - 0.5*(Z3 + Z2); 
                    if T2 < T1 & Z3 > Z1; T2 = 360; T3 = 360;
                    elseif Z3 < Z2 & T1 < T2; T1 = 360; 
                    end
                    Tcoord = 0.5*(T2 + T1); ph = SOLID.Ch*pho*(1 - exp(-zmid/zo)); pf = SOLID.Cw*SOLID.mewU*pho*(1 - exp(-zmid/zo)); 
                    if LOAD.type(L) == 'd';
                        phce = SOLID.Ch*phco*(1 - exp(-zmid/zoc)); phae = 2*ph - phce; pfce = SOLID.Cw*SOLID.mewL*phco*(1 - exp(-zmid/zoc)); pfae = SOLID.mewL*(2*pf - pfce);
                        if Tcoord >= POS_2min & Tcoord < POS_min; % within the right adjacent region
                            phh = phae; pff = pfae;
                        elseif (out == 0 & Tcoord >= POS_min & Tcoord < POS_max); % within the flow channel
                            phh = phce; pff = pfce;
                        elseif ((out == 1 & Tcoord >= POS_min & Tcoord <= 360) | (out == 1 & Tcoord >= 0 & Tcoord < POS_max)); 
                            phh = phce; pff = pfce;
                        elseif Tcoord >= POS_max & Tcoord < POS_2max; % within the left adjacent region
                            phh = phae;  pff = pfae;       
                        else phh = ph; pff = pf;
                        end                            
                    end                       
                    for Ee = 1:length(ee); txt1(length(txt1)+1) = ee(Ee); txt2(length(txt2)+1) = ee(Ee); end
                    for Ph = 1:length(txtP); txt1(length(txt1)+1) = txtP(Ph); end
                    phh = num2str(phh); for Ph = 1:length(phh); txt1(length(txt1)+1) = phh(Ph); end
                    for F1 = 1:length(txtF1); txt2(length(txt2)+1) = txtF1(F1); end
                    pff = num2str(pff); for Pf = 1:length(pff); txt2(length(txt2)+1) = pff(Pf); end
                    for F2 = 1:length(txtF2); txt2(length(txt2)+1) = txtF2(F2); end
                    fprintf(fid,'%s\n',txt1); fprintf(fid,'%s\n',txt2);
                end
                if drawP == 1; figure; 
                    plot(Pr.z,Pr.Ph,'k.'); hold on; plot(Pr.z,Pr.Pf,'r.'); title('Axial Horizontal Pressure and Frictional Traction Distribution'); 
                    xlabel('z, mm'); ylabel('P, N/mm2');  figure;
                    plot(Pr.T,Pr.Ph,'k.'); hold on; plot(Pr.T,Pr.Pf,'r.'); title('Circumferential Horizontal Pressure and Frictional Traction Distribution'); 
                    xlabel('T, degrees'); ylabel('P, N/mm2');                      
                end               
            end
        end
        fprintf(fid,'%s\n','**'); 
        
        %---% Writing Output Requests for First Load Step
        fprintf(fid,'%s\n','*OUTPUT, FIELD');
        fprintf(fid,'%s\n','*NODE OUTPUT'); fprintf(fid,'%s\n','RF, TF, U'); 
        fprintf(fid,'%s\n','*ELEMENT OUTPUT, DIRECTIONS=YES'); fprintf(fid,'%s\n','S');   
        fprintf(fid,'%s\n','*OUTPUT, HISTORY, VARIABLE=PRESELECT');
        fprintf(fid,'%s\n','*END STEP'); fprintf(fid,'%s\n','**'); 
    end
    
    %---% Writing Second Created Buckling Linear Perturbation Step (if requested)
    if ANA(2) == '5' | ANA(2) == '6'; % Buckling eigenvalue analysis (linear or non linear) or Riks non linear analysis
        if Ttot == 90 & ANA(2) == '5' & (anti == 1 | anti == 2); Buckles = 2; k = 1; else; Buckles = 1; k = 1; end % Quarter shell, requires a second buckling step with axisymmetry (if requested through anti = 1 or 2)
        if ANA(2) == '5' & anti == 2; k = 2; end
        for K = k:Buckles;
            if ANA(2) == '5'; % Buckling eigenvalue analysis only
                if K == 1; txt = 'SYMMETRY CONDITIONS'; name = '"SYMMETRICAL BUCKLING STEP"'; elseif K == 2; txt = 'ANTISYMMETRY CONDITIONS'; name = '"ANTISYMMETRICAL BUCKLING STEP"'; end
                fprintf(fid,'%s\n','**'); eige = (['']); if K == 2;  fprintf(fid,'%s\n','**'); end
                if ANA(4) == '0'; nlgeom = ''; end % Linear geometry
                if ANA(4) == '1'; nlgeom = ', NLGEOM=YES'; end % Nonlinear geometry                  
                fprintf(fid,'%s\n',['*STEP, NAME=',name,', PERTURBATION',nlgeom]); fprintf(fid,'%s\n',txt); 
                if ANA(3) == '1'; esolv = ' EIGENSOLVER=LANCZOS'; % Lanczos eigensolver for >= 20 eigenvalues
                    for I = 1:length(eigenvalues); 
                        if eigenvalues(I) ~= def; eg = num2str(eigenvalues(I)); for J = 1:length(eg); eige(length(eige)+1) = eg(J); end; end; eige(length(eige)+1) = ','; eige(length(eige)+1) = ' '; 
                    end
                end
                if ANA(3) == '2'; esolv = ' EIGENSOLVER=SUBSPACE'; % Subspace default eigensolver for < 20 eigenvalues  
                    for I = 1:length(eigenvalues);
                        if I == 1; eg = num2str(eigenvalues(I)); for J = 1:length(eg); eige(length(eige)+1) = eg(J); end; eige(length(eige)+1) = ','; eige(length(eige)+1) = ' '; end
                        if I == 2; if eigenvalues(I) ~= def; eg = num2str(eigenvalues(I)); for J = 1:length(eg); eige(length(eige)+1) = eg(J); end; end; eige(length(eige)+1) = ','; eige(length(eige)+1) = ' '; end
                        if I == 3; if eigenvalues(I) == def; eg = num2str(min(2*eigenvalues(1),8+eigenvalues(1))); for J = 1:length(eg); eige(length(eige)+1) = eg(J); end; end; eige(length(eige)+1) = ','; eige(length(eige)+1) = ' '; end
                        if I == 4; if eigenvalues(I) == def; eige(length(eige)+1) = '3'; eige(length(eige)+1) = '0'; end; end
                    end
                end
                fprintf(fid,'%s\n',['*BUCKLE,',esolv]); 
                fprintf(fid,'%s\n',eige);                
            elseif ANA(2) == '6'; % Riks nonlinear analysis only
                if ANA(4) == '0'; nlgeom = 'NO'; elseif ANA(4) == '1'; nlgeom = 'YES'; end
                fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n',['*STEP, NAME=RIKS STEP, NLGEOM=',nlgeom,', INC=',num2str(inc)]); fprintf(fid,'%s\n','*STATIC, RIKS'); RIKS = (['']);
                for I = 1:length(Riks)
                    if I <= 4; % Default values unless specified
                        if I == 1 & Riks(I) == 0; Riks(I) = 0.01; end % 1  - Initial increment in arc length along static equilibrium path (default is total arc length of step)
                        if I == 2 & Riks(I) == 0; Riks(I) = 1; end % 2  - Total arc length scale factor (default is 1.0)
                        if I == 3 & Riks(I) == 0; Riks(I) = 1e-10; end % 3  - Minimum arc length increment (default is initial arc length or 10e-5 times the total arc length, whichever is smaller)
                        if I == 4 & Riks(I) == 0; Riks(I) = 0.05; end % 4  - Maximum arc length increment (default is no upper limit)
                    end    
                    if (I == 6 & Riks(I) == -1) | (I == 6 & Riks(I) == -2); RIKS(length(RIKS)+1) = 'R'; RIKS(length(RIKS)+1) = 'I'; RIKS(length(RIKS)+1) = 'K';RIKS(length(RIKS)+1) = 'S'; RIKS(length(RIKS)+1) = ',';
                    elseif I ~= 6; rk = num2str(Riks(I)); for J = 1:length(rk); RIKS(length(RIKS)+1) = num2str(rk(J)); end; RIKS(length(RIKS)+1) = ','; end 
                end  
                RIKS(length(RIKS)) = ''; fprintf(fid,'%s\n',RIKS);
            end       
            fprintf(fid,'%s\n','**'); if ANA(2) == '6' | ANA(2) == '5'; Aend = 1; else; Aend = 2; end
            for A = 1:Aend; 
                if ANA(2) == '6' | ANA(2) == '5'; fprintf(fid,'%s\n','*BOUNDARY, OP=NEW'); else; fprintf(fid,'%s\n',['*BOUNDARY, OP=NEW, LOAD CASE=',num2str(A)]); end
                for B = 1:length(BC.type); no = 0;
                    if BC.type(B) == 11; if Ttot ~= 360; BCs = 'YSYMM'; else; no = 1; end; end % symmetry about line of constant y, YSYMM for U2 = 0 (i.e. left)
                    if BC.type(B) == 12; % symmetry (or antisymmetry) about line of constant x, XSYMM for U1 = 0 (i.e. right)
                        if Ttot ~= 360;
                            if K == 1; BCs = 'XSYMM'; elseif K == 2; BCs = 'XASYMM'; end; 
                        else; no = 1;
                        end 
                    end
                    if BC.type(B) == 13; BCs = 'ZSYMM'; end % symmetry about line of constant z, ZSYMM for U3 = 0 
                    if BC.type(B) == 22; BCs = 'PINNED'; end % pinned
                    if BC.type(B) == 33; BCs = 'ENCASTRE'; end % encastr�  
                    if BC.where(B) == 0; ndsn = 'Bottom'; nds = NSet.Bottom; end % bottom set of nodes
                    if BC.where(B) == 11; if Ttot ~= 360; ndsn = 'Left'; nds = NSet.Left; else; no = 1; end; end % left side set of nodes
                    if BC.where(B) == 12; if Ttot ~= 360; ndsn = 'Right'; nds = NSet.Right; else; no = 1; end; end % right side set of nodes
                    if BC.where(B) == 2; ndsn = 'Top'; nds = NSet.Top; end % top set of nodes  
                    if BC.type(B) ~= 3 & no ~= 1; fprintf(fid,'%s\n',([ndsn,', ',BCs])); end        
                    if BC.type(B) == 3; % 3 - the simply supported S3 boundary condition (radially and circumferentially restrained for displacement), U1 = U2 = 0
                        BCs = [1 2]; for I = 1:length(BCs); fprintf(fid,'%s\n',([ndsn,', ',num2str(BCs(I))])); end; end 
                end 
            end 
            fprintf(fid,'%s\n','**');   
            if no == 0; LOAD.step(L) = 2; end
            for L = 1:length(LOAD.value);
                if LOAD.type(L) == 'a' & LOAD.step(L) == 2; % internal pressure defined in second analysis step
                    fprintf(fid,'%s\n','*DSLOAD');
                    txt = (['INNER_SURFACE, P, ',num2str(LOAD.value(L))]);
                    fprintf(fid,'%s\n',txt);           
                end
                if LOAD.type(L) == 'b' & LOAD.step(L) == 2; % shell edge load along the top edge defined in second analysis step
                    fprintf(fid,'%s\n','*DSLOAD');
                    txt = (['TOP_EDGE, EDNOR, ',num2str(LOAD.value(L))]);
                    fprintf(fid,'%s\n',txt);
                end
                if (LOAD.type(L) == 'c' | LOAD.type(L) == 'd') & LOAD.step(L) == 2; clear('txt'); % Janssen pressure generates both normal pressure and friction surface traction
                    if LOAD.type(L) == 'd'; tx = ' with eccentric discharge flow channel'; THc = THc*180/pi; 
                        POS_2min = SOLID.chan - 2*THc; if POS_2min < 0; POS_2min = 360 + POS_2min; out = 1; end
                        POS_min = SOLID.chan - THc; if POS_min < 0; POS_min = 360 + POS_min; out = 1; end
                        POS_max = SOLID.chan + THc; if POS_max > 360; POS_max = POS_max - 360; out = 1; end
                        POS_2max = SOLID.chan + 2*THc; if POS_2max > 360; POS_2max = POS_2max - 360; out = 1; end                         
                    else tx = ''; 
                    end
                    fprintf(fid,'%s\n',['** Definition of Janssen internal pressures and frictional tractions',tx]); 
                    fprintf(fid,'%s\n','*DLOAD'); txt = 'SHELL_INSTANCE.'; txtP = ', P, '; txtF1 = ', TRSHR, '; txtF2 = ', 0., 0., -1.'; out = 0;
                    for E = 1:length(Elements.index);
                        clc; disp(['      Writing Janssen pressures - ',num2str(E*100/length(Elements.index)),' % complete']);
                        if Elements.region(E) == max(Rsl.region) & ROOF.h_els ~= 0; continue; end
                        txt1 = txt; txt2 = txt; ee = num2str(E);
                        e1 = Elements.nodes(E,1); f1 = find(Nodes.index == e1); e2 = Elements.nodes(E,2); f2 = find(Nodes.index == e2); e3 = Elements.nodes(E,3); f3 = find(Nodes.index == e3);
                        Z1 = Nodes.Z(f1); Z2 = Nodes.Z(f2); Z3 = Nodes.Z(f3); T1 = Nodes.T(f1); T2 = Nodes.T(f2); T3 = Nodes.T(f3);
                        zmid = Htot - 0.5*(Z3 + Z2); 
                        if T2 < T1 & Z3 > Z1; T2 = 360; T3 = 360;
                        elseif Z3 < Z2 & T1 < T2; T1 = 360; 
                        end
                        Tcoord = 0.5*(T2 + T1); ph = SOLID.Ch*pho*(1 - exp(-zmid/zo)); pf = SOLID.Cw*SOLID.mewU*pho*(1 - exp(-zmid/zo)); 
                        if LOAD.type(L) == 'd';
                            phce = SOLID.Ch*phco*(1 - exp(-zmid/zoc)); phae = 2*ph - phce; pfce = SOLID.Cw*SOLID.mewL*phco*(1 - exp(-zmid/zoc)); pfae = SOLID.mewL*(2*pf - pfce);
                            if Tcoord >= POS_2min & Tcoord < POS_min; % within the right adjacent region
                                phh = phae; pff = pfae;
                            elseif (out == 0 & Tcoord >= POS_min & Tcoord < POS_max); % within the flow channel
                                phh = phce; pff = pfce;
                            elseif ((out == 1 & Tcoord >= POS_min & Tcoord <= 360) | (out == 1 & Tcoord >= 0 & Tcoord < POS_max)); 
                                phh = phce; pff = pfce;
                            elseif Tcoord >= POS_max & Tcoord < POS_2max; % within the left adjacent region
                                phh = phae;  pff = pfae;       
                            else phh = ph; pff = pf;
                            end                            
                        end                       
                        for Ee = 1:length(ee); txt1(length(txt1)+1) = ee(Ee); txt2(length(txt2)+1) = ee(Ee); end
                        for Ph = 1:length(txtP); txt1(length(txt1)+1) = txtP(Ph); end
                        phh = num2str(phh); for Ph = 1:length(phh); txt1(length(txt1)+1) = phh(Ph); end
                        for F1 = 1:length(txtF1); txt2(length(txt2)+1) = txtF1(F1); end
                        pff = num2str(pff); for Pf = 1:length(pff); txt2(length(txt2)+1) = pff(Pf); end
                        for F2 = 1:length(txtF2); txt2(length(txt2)+1) = txtF2(F2); end
                        fprintf(fid,'%s\n',txt1); fprintf(fid,'%s\n',txt2);
                    end
                end
            end
            fprintf(fid,'%s\n','**');     
            fprintf(fid,'%s\n','*OUTPUT, FIELD');
            fprintf(fid,'%s\n','*NODE OUTPUT'); fprintf(fid,'%s\n','RF, TF, U'); 
            fprintf(fid,'%s\n','*ELEMENT OUTPUT, DIRECTIONS=YES'); fprintf(fid,'%s\n','S');   
            if ANA(2) == '6'; fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n','*OUTPUT, HISTORY'); fprintf(fid,'%s\n','*NODE OUTPUT, NSET=RIKS'); fprintf(fid,'%s\n','U1, U2, U3'); end  
            fprintf(fid,'%s\n','**'); fprintf(fid,'%s\n','*END STEP');
        end
    end
    
    %---% Closing File    
    fclose(fid);
end
MPI_Finalize; % Closing MPI
if (my_rank ~= MatMPI_Host_rank(comm)); exit; end
MPI_Delete_all;

% Display routines
clc; disp(' '); disp('      Commenced.');
disp(['      ',ddd']); disp(' ');
if ANA(2) == '0'; txt1 = ('General Static Analysis with'); 
    if ANA(3) == '0'; txt2 = (' Linear Geometry'); 
    elseif ANA(3) == '1'; txt2 = (' Nonlinear Geometry and Extrapolation'); 
    elseif ANA(3) == '2'; txt2 = (' Nonlinear Geometry and Parabolic Extrapolation'); end
    disp(['      ',txt1,txt2]); end
if ANA(2) == '5'; txt1 = ('Eigenvalue Buckling Analysis using'); 
    if ANA(3) == '1'; txt2 = (' the Lanczos Solver with'); elseif ANA(3) == '2'; txt2 = (' the Subspace Solver with'); end
    if ANA(4) == '0'; txt3 = (' Linear Geometry'); elseif ANA(4) == '1';
        if ANA(5) == '1'; txt3 = (' Nonlinear Geometry and Linear Extrapolation'); elseif ANA(5) == '2'; txt3 = (' Nonlinear Geometry and Parabolic Extrapolation'); end; end
    disp(['      ',txt1,txt2,txt3]); disp(['      Requested Number of Eigenvalues      ',num2str(eigenvalues(1))]); end
if ANA(2) == '6'; 
    if ANA(4) == '0'; txt1 = ('Riks Geometrically LINEAR Analysis'); elseif ANA(4) == '1'; txt1 = ('Riks Geometrically Nonlinear Analysis'); end
    if ANA(3) == '1'; txt2 = (' with Preceding Static Step'); else; txt2 = (''); end
    disp(['      ',txt1,txt2]); end; 

disp(' '); disp(['      ',num2str(length(Nodes.index)),'      Nodes created']); tip = (''); disp(' '); th = Rtot*Ttot*pi/180;
for E = 1:length(Rsl.type);
    if Rsl.type(E) == 'a'; tip(E,:) = 'S4    '; els(E) = Rsl.Z(E)*Rsl.Ttot; k = 1;
    elseif Rsl.type(E) == 'b'; tip(E,:) = 'S4R   '; els(E) = Rsl.Z(E)*Rsl.Ttot; k = 1;
    elseif Rsl.type(E) == 'c'; tip(E,:) = 'S4R5  '; els(E) = Rsl.Z(E)*Rsl.Ttot; k = 1;
    elseif Rsl.type(E) == 'd'; tip(E,:) = 'S3    '; els(E) = Rsl.Z(E)*Rsl.Ttot*2; k = 1;
    elseif Rsl.type(E) == 'e'; tip(E,:) = 'STRI3 '; els(E) = Rsl.Z(E)*Rsl.Ttot*2; k = 1;
    elseif Rsl.type(E) == 'f'; tip(E,:) = 'STRI65'; els(E) = Rsl.Z(E)*Rsl.Ttot/2; k = 0.5; 
    elseif Rsl.type(E) == 'g'; tip(E,:) = 'S8R   '; els(E) = Rsl.Z(E)*Rsl.Ttot/4; k = 0.5;
    elseif Rsl.type(E) == 'h'; tip(E,:) = 'S8R5  '; els(E) = Rsl.Z(E)*Rsl.Ttot/4; k = 0.5;
    elseif Rsl.type(E) == 'j'; tip(E,:) = 'S9R5  '; els(E) = Rsl.Z(E)*Rsl.Ttot/4; k = 0.5;
    end
    z = Rsl.h2(E) - Rsl.h1(E); RZ = k*z/Rsl.Z(E); RT = k*th/Rsl.Ttot;
    if E == length(Rsl.type); bit = [' in sloping roof, t = ',num2str(Rsl.t(E)),' mm.'];
    else; bit = [', t = ',num2str(Rsl.t(E)),' mm.     Resolution;   Z - ',num2str(Rsl.Z(E)),' (',num2str(RZ),' mm, ',num2str(RZ/sqrt(Rtot*Rsl.t(E))),' sqRt),   T - ',num2str(Rsl.Ttot),' (',num2str(RT),' mm, ',num2str(RT/sqrt(Rtot*Rsl.t(E))),' sqRt - approx.)'];
    end
    disp(['      ',num2str(els(E)),'      ',tip(E,:),' Elements created',bit]);
end
disp(' '); disp(['      ',num2str(sum(els)),' Elements created']); disp(' ');
if ANA(2) == '6' & Riks(6) == -2; htxt = [', sniping node ',num2str(node)]; Head = [Heading,htxt]; clear('Heading'); Heading = Head; clear('Head'); end
if write == 1; disp(['      ABAQUS Input file written:    ',FileName]); end

if draw == 1; figure;  
    plot3(cos(Nodes.T*p1).*Nodes.R,sin(Nodes.T*p1).*Nodes.R,Nodes.Z,'k.'); xlabel('r axis'); ylabel('theta axis'); zlabel('z axis'); hold on; 
    if do == 0; title('No weld depression, standard geometry'); else; title(['TYPES ',WELD.type(1),' weld, with amplitude of depression ',num2str(WELD.ampt(1)/t),' thicknesses (t = ',num2str(t),'), ',tip(1,:),' elements']); end
    set(findobj('type', 'text'), 'color', 'black'); disp(' '); disp('      Mesh drawn');
    if labels == 1;
        for I = 1:length(Nodes.index); text(cos(Nodes.T(I)*p1)*Nodes.R(I),sin(Nodes.T(I)*p1)*Nodes.R(I),Nodes.Z(I),num2str(Nodes.index(I))); end
        disp('      Mesh labelled');
    end
    set(findobj('type', 'text'), 'color', 'red');
    for E = 1:length(Elements.index);         
        N1 = find(Nodes.index == Elements.nodes(E,1)); n1 = N1; N2 = find(Nodes.index == Elements.nodes(E,2)); n2 = N2;
        N3 = find(Nodes.index == Elements.nodes(E,3)); n3 = N3; 
        if char(Elements.type(E)) ~= 'd' & char(Elements.type(E)) ~= 'e' & char(Elements.type(E)) ~= 'f'; N4 = find(Nodes.index == Elements.nodes(E,4)); n4 = N4; end
        plot3([cos(Nodes.T(n1)*p1)*Nodes.R(n1),cos(Nodes.T(n2)*p1)*Nodes.R(n2)],[sin(Nodes.T(n1)*p1)*Nodes.R(n1),sin(Nodes.T(n2)*p1)*Nodes.R(n2)],[Nodes.Z(n1),Nodes.Z(n2)]);
        plot3([cos(Nodes.T(n2)*p1)*Nodes.R(n2),cos(Nodes.T(n3)*p1)*Nodes.R(n3)],[sin(Nodes.T(n2)*p1)*Nodes.R(n2),sin(Nodes.T(n3)*p1)*Nodes.R(n3)],[Nodes.Z(n2),Nodes.Z(n3)]);
        if char(Elements.type(E)) ~= 'd' & char(Elements.type(E)) ~= 'e' & char(Elements.type(E)) ~= 'f';
            plot3([cos(Nodes.T(n3)*p1)*Nodes.R(n3),cos(Nodes.T(n4)*p1)*Nodes.R(n4)],[sin(Nodes.T(n3)*p1)*Nodes.R(n3),sin(Nodes.T(n4)*p1)*Nodes.R(n4)],[Nodes.Z(n3),Nodes.Z(n4)]);
            plot3([cos(Nodes.T(n4)*p1)*Nodes.R(n4),cos(Nodes.T(n1)*p1)*Nodes.R(n1)],[sin(Nodes.T(n4)*p1)*Nodes.R(n4),sin(Nodes.T(n1)*p1)*Nodes.R(n1)],[Nodes.Z(n4),Nodes.Z(n1)]);
        else
            plot3([cos(Nodes.T(n3)*p1)*Nodes.R(n3),cos(Nodes.T(n1)*p1)*Nodes.R(n1)],[sin(Nodes.T(n3)*p1)*Nodes.R(n3),sin(Nodes.T(n1)*p1)*Nodes.R(n1)],[Nodes.Z(n3),Nodes.Z(n1)]);
        end        
        if labels == 1; 
            if char(Elements.type(E)) == 'a' | char(Elements.type(E)) == 'b' | char(Elements.type(E)) == 'c'; py = 0.5; px = 0.5; ntop = n4;
            elseif char(Elements.type(E)) == 'd' | char(Elements.type(E)) == 'e' | char(Elements.type(E)) == 'f'; ntop = n3; if Elements.alt(E) == 1; px = 0.75; py = 0.25; elseif Elements.alt(E) == 2; px = 0.75; py = 0.25; end; 
            elseif char(Elements.type(E)) == 'g' | char(Elements.type(E)) == 'h' | char(Elements.type(E)) == 'j'; 
                py = 0.25; px = 0.5; ntop = n4; end
            text(cos(Nodes.T(n1)*p1)*Nodes.R(n1)+px*([cos(Nodes.T(n2)*p1)*Nodes.R(n2)-cos(Nodes.T(n1)*p1)*Nodes.R(n1)]),sin(Nodes.T(n1)*p1)*Nodes.R(n1)+px*([sin(Nodes.T(n2)*p1)*Nodes.R(n2)-sin(Nodes.T(n1)*p1)*Nodes.R(n1)]),...
                Nodes.Z(n1)+py*[Nodes.Z(ntop)-Nodes.Z(n1)],num2str(Elements.index(E)));
        end
    end; 
end
disp(' '); disp(['      Total Cylinder Height:    ',num2str(Htot),' mm']);
disp(['      Cylinder Radius:    ',num2str(Rtot),' mm']);
disp(['      Cylinder Thicknesses:    ',num2str(Rsl.t),' mm']);
disp(['      Modelled Circumferential Spread:    ',num2str(Ttot),' degrees']); disp(' '); uni = [];
for R = 2:(length(Rsl.t)-1);
    if Rsl.t(R) == Rsl.t(R-1); uni(length(uni)+1) = 1; end
end
if sum(uni) == (length(Rsl.t)-1); 
    disp(['      Radius to Thickness Ratio:    ',num2str(Rtot/t)]);
    disp(['      Length to Radius Aspect Ratio:    ',num2str(Htot/Rtot)]); disp(' '); 
    disp(['      Classical Elastic Critical Buckling Sress for cylinder only, scl:    ',num2str(sigmacl),' MPa']);
    disp(['      Corresponding Critical Compressive Line Force for cylinder only:    ',num2str(sigmacl*t),' N/mm']); disp(' '); 
end
if do > 0; 
    for W = 1:length(WELD.type);
        disp(['      Type ',WELD.type(W),' Weld Depression:    ',num2str(WELD.ampt(W)),' t top   at z = ',num2str(WELD.Zloc(W)),' mm']); 
    end; 
end
disp('      Completed.');
disp(['      ',datestr(now)]); disp(' ');
if Rsl.type(1) == 'g' | Rsl.type(1) == 'h'; st = 2; else; st = 1; end
if wipe == 1; clear all; disp('      Memory cleared'); disp(' '); end